(() => {
  // extension/src/chat-page-bridge.ts
  function captureChatFromPage() {
    const limit = 2 * 1024 * 1024;
    const encoder = new TextEncoder();
    const visible = (node) => {
      for (let current = node; current; current = current.parentElement) {
        const style = getComputedStyle(current);
        if (current.hasAttribute("hidden") || current.getAttribute("aria-hidden") === "true" || style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return false;
      }
      return true;
    };
    const excluded = "form,input,textarea,select,button,[contenteditable]:not([contenteditable='false']),script,style,noscript,[hidden],[aria-hidden='true'],[data-sensitive],[autocomplete='current-password'],[autocomplete='new-password']";
    const cleanText = (node) => {
      const chunks = [];
      const visit = (item) => {
        if (item.nodeType === Node.TEXT_NODE) {
          if (item.textContent) chunks.push(item.textContent);
          return;
        }
        if (!(item instanceof Element) || item.matches(excluded) || !visible(item)) return;
        const block = /^(DIV|P|PRE|LI|UL|OL|H[1-6]|BLOCKQUOTE|BR|SECTION|ARTICLE)$/.test(item.tagName);
        if (block) chunks.push("\n");
        for (const child of item.childNodes) visit(child);
        if (block) chunks.push("\n");
      };
      visit(node);
      return chunks.join("").replace(/\r/g, "").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
    };
    const url = new URL(location.href);
    url.search = "";
    url.hash = "";
    url.username = "";
    url.password = "";
    const host = url.hostname;
    const provider = /(^|\.)(chatgpt\.com|chat\.openai\.com)$/.test(host) ? "chatgpt" : /(^|\.)claude\.ai$/.test(host) ? "claude" : host === "gemini.google.com" ? "gemini" : "unknown";
    const result = {
      title: document.title.slice(0, 1e3),
      url: url.href,
      provider,
      captured_at: (/* @__PURE__ */ new Date()).toISOString(),
      messages: [],
      scope: "current-page-dom",
      warning: "Only rendered messages currently loaded on this page are captured; earlier history and provider memory may be absent."
    };
    const selectors = "[data-message-author-role='user'],[data-message-author-role='assistant'],[data-testid='user-message'],[data-testid='assistant-message'],[data-role='user'],[data-role='assistant'],.font-user-message,.font-claude-message,user-query,model-response";
    const candidates = Array.from(document.querySelectorAll(selectors));
    for (const node of candidates) {
      if (node.parentElement?.closest(selectors) || !visible(node) || node.closest(excluded)) continue;
      const content = cleanText(node);
      if (!content) continue;
      const roleAttr = node.getAttribute("data-message-author-role") ?? node.getAttribute("data-role");
      const role = roleAttr === "user" || node.matches("[data-testid='user-message'],.font-user-message,user-query") ? "user" : "assistant";
      result.messages.push({ role, content });
      if (encoder.encode(JSON.stringify(result)).byteLength > limit) throw new Error("Current-page capture exceeds the 2 MiB limit. Select a smaller transcript.");
    }
    if (!result.messages.length) {
      const selection = window.getSelection();
      let content = "";
      if (selection && !selection.isCollapsed && selection.rangeCount) {
        const range = selection.getRangeAt(0);
        const root = range.commonAncestorContainer.nodeType === Node.ELEMENT_NODE ? range.commonAncestorContainer : range.commonAncestorContainer.parentElement;
        if (root && !root.closest(excluded) && visible(root)) {
          const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
          const chunks = [];
          let item;
          while (item = walker.nextNode()) {
            const parent = item.parentElement;
            if (!parent || parent.closest(excluded) || !visible(parent) || !range.intersectsNode(item)) continue;
            const value = item.textContent ?? "";
            const start = item === range.startContainer ? range.startOffset : 0;
            const end = item === range.endContainer ? range.endOffset : value.length;
            chunks.push(value.slice(start, end));
          }
          content = chunks.join("\n").trim();
        }
      }
      if (content) result.warning += " Selected page text was captured with unknown speaker roles.";
      else {
        const main = document.querySelector("main,[role='main']");
        if (main && visible(main)) content = cleanText(main);
        if (content) result.warning += " Main-page text was captured as a generic fallback with unknown speaker roles; review it before saving.";
      }
      if (content) result.messages.push({ role: "unknown", content });
    }
    if (!result.messages.length) throw new Error("No visible conversation text found on this page.");
    if (encoder.encode(JSON.stringify(result)).byteLength > limit) throw new Error("Current-page capture exceeds the 2 MiB limit. Select a smaller transcript.");
    return result;
  }

  // extension/src/brain.ts
  function installBrain() {
    if (!/^https?:$/.test(location.protocol) || document.getElementById("alethech-brain")) return;
    const lifetime = new AbortController();
    const button = document.createElement("button");
    button.id = "alethech-brain";
    button.type = "button";
    button.dataset.sensitive = "true";
    button.textContent = "\u{1F9E0}";
    button.title = "Alethech \u2014 arrastra para mover; pulsa para revisar y guardar la conversaci\xF3n";
    button.setAttribute("aria-label", "Capturar conversaci\xF3n con Alethech");
    button.style.cssText = "all:initial!important;position:fixed!important;z-index:2147483647!important;width:48px!important;height:48px!important;border-radius:50%!important;background:#7c5cff!important;color:white!important;border:2px solid #fff!important;box-shadow:0 4px 20px #0006!important;display:grid!important;place-items:center!important;font:24px sans-serif!important;cursor:grab!important;touch-action:none!important;user-select:none!important;";
    const status = document.createElement("div");
    status.dataset.sensitive = "true";
    status.setAttribute("role", "status");
    status.style.cssText = "position:fixed!important;bottom:76px!important;right:20px!important;z-index:2147483647!important;max-width:280px!important;background:#0d1117!important;color:#fff!important;padding:8px!important;border-radius:8px!important;font:12px/1.5 sans-serif!important;";
    status.hidden = true;
    let x = Math.max(0, innerWidth - 68), y = Math.max(0, innerHeight - 68);
    let pointer = null;
    let dragged = false;
    let pending = false;
    const position = () => {
      x = Math.max(0, Math.min(x, innerWidth - 48));
      y = Math.max(0, Math.min(y, innerHeight - 48));
      button.style.setProperty("left", `${x}px`, "important");
      button.style.setProperty("top", `${y}px`, "important");
    };
    position();
    const options = { signal: lifetime.signal };
    button.addEventListener("focus", () => button.style.setProperty("outline", "3px solid #7de2a8", "important"), options);
    button.addEventListener("blur", () => button.style.setProperty("outline", "none", "important"), options);
    button.addEventListener("pointerdown", (event) => {
      if (!event.isTrusted || !event.isPrimary || event.button !== 0) return;
      dragged = false;
      pointer = { id: event.pointerId, startX: event.clientX, startY: event.clientY, x, y };
      button.setPointerCapture(event.pointerId);
    }, options);
    button.addEventListener("pointermove", (event) => {
      if (!pointer || event.pointerId !== pointer.id) return;
      if (Math.hypot(event.clientX - pointer.startX, event.clientY - pointer.startY) > 5) dragged = true;
      if (dragged) {
        x = pointer.x + event.clientX - pointer.startX;
        y = pointer.y + event.clientY - pointer.startY;
        position();
      }
    }, options);
    button.addEventListener("pointerup", () => {
      pointer = null;
    }, options);
    button.addEventListener("pointercancel", () => {
      pointer = null;
      dragged = true;
    }, options);
    button.addEventListener("lostpointercapture", () => {
      pointer = null;
    }, options);
    button.addEventListener("click", async (event) => {
      if (!event.isTrusted || pending) return;
      if (dragged && event.detail !== 0) {
        dragged = false;
        return;
      }
      dragged = false;
      pending = true;
      button.setAttribute("aria-busy", "true");
      status.hidden = true;
      try {
        const capture = captureChatFromPage();
        const response = await chrome.runtime.sendMessage({ type: "alethech.open-capture", capture });
        if (!response?.ok) throw new Error("No se pudo abrir la revisi\xF3n. Vuelve a intentarlo.");
      } catch (error) {
        status.textContent = error instanceof Error ? error.message.slice(0, 240) : "No se pudo capturar la conversaci\xF3n.";
        status.hidden = false;
      } finally {
        pending = false;
        button.removeAttribute("aria-busy");
      }
    }, options);
    window.addEventListener("resize", position, options);
    window.addEventListener("pagehide", () => {
      lifetime.abort();
      button.remove();
      status.remove();
    }, { once: true, signal: lifetime.signal });
    document.body.append(button, status);
  }
  installBrain();
  window.addEventListener("pageshow", installBrain);
})();
